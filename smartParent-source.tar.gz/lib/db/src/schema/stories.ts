import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const storiesTable = pgTable("stories", {
  id: serial("id").primaryKey(),
  prompt: text("prompt").notNull(),
  title: text("title").notNull(),
  scene: text("scene"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const comicPanelsTable = pgTable("comic_panels", {
  id: serial("id").primaryKey(),
  storyId: integer("story_id").notNull().references(() => storiesTable.id, { onDelete: "cascade" }),
  panelNumber: integer("panel_number").notNull(),
  narration: text("narration").notNull(),
  imageB64: text("image_b64"),
});

export const insertStorySchema = createInsertSchema(storiesTable).omit({ id: true, createdAt: true });
export const insertComicPanelSchema = createInsertSchema(comicPanelsTable).omit({ id: true });

export type InsertStory = z.infer<typeof insertStorySchema>;
export type Story = typeof storiesTable.$inferSelect;
export type InsertComicPanel = z.infer<typeof insertComicPanelSchema>;
export type ComicPanel = typeof comicPanelsTable.$inferSelect;
