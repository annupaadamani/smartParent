import { useRoute, Link } from "wouter";
import { ArrowLeft, BookOpen, Clock } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { useGetStory } from "@/hooks/use-stories";

export function StoryView() {
  const [, params] = useRoute("/story/:id");
  const storyId = params?.id ? parseInt(params.id, 10) : null;

  const { data: story, isLoading, error } = useGetStory(storyId || 0, {
    query: {
      enabled: !!storyId,
    }
  });

  if (!storyId) return <div className="p-10 text-center font-display text-2xl">Story not found.</div>;

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-12 w-full animate-pulse">
        <div className="w-24 h-8 bg-muted rounded-full mb-8" />
        <div className="w-3/4 h-12 bg-muted rounded-2xl mb-4 mx-auto" />
        <div className="w-1/2 h-6 bg-muted rounded-full mb-16 mx-auto" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="bg-white rounded-[2rem] p-4 shadow-sm border-2 border-border">
              <div className="w-full aspect-square bg-muted rounded-xl mb-6" />
              <div className="w-full h-24 bg-muted rounded-xl" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error || !story) {
    return (
      <div className="p-10 text-center flex flex-col items-center gap-4">
        <div className="w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center mb-4">
          <BookOpen className="w-10 h-10 text-destructive" />
        </div>
        <h2 className="font-display text-2xl font-bold text-foreground">Oops, couldn't open this book.</h2>
        <p className="text-muted-foreground">The story might have been deleted or is unavailable.</p>
        <Link href="/" className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-bold">
          Go Back Home
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-12 w-full">
      {/* Header */}
      <Link 
        href="/history" 
        className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white border border-border shadow-sm text-muted-foreground font-bold hover:text-foreground hover:bg-muted transition-all mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Library
      </Link>

      <div className="text-center mb-12 sm:mb-16">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-4xl sm:text-5xl md:text-6xl font-extrabold text-foreground mb-4 leading-tight"
        >
          {story.title}
        </motion.h1>
        
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex items-center justify-center gap-4 text-muted-foreground font-semibold"
        >
          <div className="flex items-center gap-1.5">
            <Clock className="w-4 h-4" />
            <span>{format(new Date(story.createdAt), 'MMMM d, yyyy')}</span>
          </div>
          {story.scene && (
            <>
              <span className="w-1.5 h-1.5 rounded-full bg-border" />
              <span className="px-3 py-1 rounded-full bg-accent/20 text-accent-foreground text-sm border border-accent/30">
                Scene: {story.scene}
              </span>
            </>
          )}
        </motion.div>
      </div>

      {/* Comic Panels Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 pb-20">
        {story.panels?.length > 0 ? (
          story.panels.map((panel, index) => (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.15 + 0.3, duration: 0.5 }}
              key={panel.id}
              className="comic-panel-shadow bg-white rounded-[2rem] p-4 sm:p-5 flex flex-col group relative"
            >
              {/* Panel Number Badge */}
              <div className="absolute -top-3 -left-3 w-10 h-10 bg-secondary text-white font-display font-bold text-xl flex items-center justify-center rounded-full shadow-md z-10 rotate-[-5deg] group-hover:scale-110 transition-transform">
                {panel.panelNumber}
              </div>

              {/* Illustration */}
              <div className="w-full aspect-square bg-muted rounded-2xl overflow-hidden mb-5 relative border border-border shadow-inner">
                {panel.imageB64 ? (
                  <img 
                    src={`data:image/png;base64,${panel.imageB64}`}
                    alt={`Illustration for panel ${panel.panelNumber}`}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground">
                    <BookOpen className="w-12 h-12 mb-2 opacity-50" />
                    <span className="font-bold">Image unavailable</span>
                  </div>
                )}
              </div>

              {/* Narration (Comic Style) */}
              <div className="flex-1 bg-yellow-50/50 border-2 border-yellow-200/50 rounded-2xl p-5 relative">
                {/* Speech bubble tail illusion */}
                <div className="absolute -top-2 left-8 w-4 h-4 bg-yellow-50/50 border-t-2 border-l-2 border-yellow-200/50 rotate-45" />
                
                <p className="font-comic text-xl sm:text-2xl text-slate-800 leading-relaxed">
                  {panel.narration}
                </p>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full py-20 text-center">
            <p className="text-xl text-muted-foreground font-bold">No comic panels found for this story.</p>
          </div>
        )}
      </div>

      {/* The End */}
      {story.panels?.length > 0 && (
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="py-10 flex flex-col items-center justify-center gap-4"
        >
          <div className="w-32 h-1 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full" />
          <h3 className="font-display text-4xl font-bold text-primary italic">The End.</h3>
          <div className="w-32 h-1 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full" />
        </motion.div>
      )}
    </div>
  );
}
