import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Send, Sparkles, Trees, Moon, Cat, Rocket, Waves, Flower2 } from "lucide-react";
import { useStoryMutations } from "@/hooks/use-stories";
import { LoadingScreen } from "@/components/LoadingScreen";
import { cn } from "@/lib/utils";

const PRESET_SCENES = [
  { id: "forest-adventure", label: "Forest Adventure", icon: Trees, color: "bg-emerald-100 text-emerald-600 border-emerald-200" },
  { id: "sleepy-time", label: "Sleepy Time", icon: Moon, color: "bg-indigo-100 text-indigo-600 border-indigo-200" },
  { id: "animal-friends", label: "Animal Friends", icon: Cat, color: "bg-orange-100 text-orange-600 border-orange-200" },
  { id: "space-journey", label: "Space Journey", icon: Rocket, color: "bg-purple-100 text-purple-600 border-purple-200" },
  { id: "underwater-world", label: "Underwater World", icon: Waves, color: "bg-cyan-100 text-cyan-600 border-cyan-200" },
  { id: "big-garden", label: "The Big Garden", icon: Flower2, color: "bg-pink-100 text-pink-600 border-pink-200" },
];

export function Home() {
  const [, setLocation] = useLocation();
  const [prompt, setPrompt] = useState("");
  const [selectedScene, setSelectedScene] = useState<string | null>(null);
  
  const { createStory } = useStoryMutations();

  const handleGenerate = async () => {
    if (!prompt.trim() && !selectedScene) return;

    try {
      const result = await createStory.mutateAsync({
        data: {
          prompt: prompt || "Make it a fun bedtime story.",
          scene: selectedScene || undefined
        }
      });
      setLocation(`/story/${result.id}`);
    } catch (error) {
      console.error("Failed to generate story:", error);
      // In a real app we'd show a toast here
    }
  };

  if (createStory.isPending) {
    return <LoadingScreen message="Illustrating the scenes..." />;
  }

  return (
    <div className="flex-1 w-full pb-20">
      {/* Hero Section */}
      <div className="relative w-full overflow-hidden bg-slate-900 rounded-b-[3rem] sm:rounded-b-[4rem] px-4 py-16 sm:py-24 shadow-2xl shadow-primary/10">
        <img 
          src={`${import.meta.env.BASE_URL}images/hero-bg.png`} 
          alt="Magical nighttime sky background" 
          className="absolute inset-0 w-full h-full object-cover opacity-70 mix-blend-screen"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-slate-900/90" />
        
        <div className="relative z-10 max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white text-sm font-bold mb-6"
          >
            <Sparkles className="w-4 h-4 text-primary" />
            <span>AI-Powered Storytelling</span>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="font-display text-4xl sm:text-6xl md:text-7xl font-bold text-white leading-tight mb-6"
          >
            Stories for your little ones, <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-secondary">
              on demand.
            </span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-lg sm:text-xl text-slate-300 font-medium max-w-2xl mx-auto"
          >
            Tired parent? Or just out of ideas? We've got you.
          </motion.p>
        </div>
      </div>

      {/* Main Creation Area */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 -mt-10 relative z-20">
        <div className="glass-card rounded-[2rem] p-6 sm:p-10 flex flex-col gap-8">
          
          {/* Prompt Input */}
          <div className="flex flex-col gap-3">
            <label htmlFor="prompt" className="font-display font-bold text-xl text-foreground ml-2">
              What's the story about?
            </label>
            <div className="relative">
              <textarea
                id="prompt"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="E.g., A brave little dinosaur who learns to share his toys..."
                className="w-full min-h-[140px] p-6 rounded-3xl bg-input border-2 border-border text-foreground text-lg placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all duration-300 resize-none font-medium"
              />
            </div>
          </div>

          {/* Preset Scenes */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between ml-2">
              <label className="font-display font-bold text-xl text-foreground">
                Or pick a magical scene
              </label>
              {selectedScene && (
                <button 
                  onClick={() => setSelectedScene(null)}
                  className="text-sm font-bold text-muted-foreground hover:text-destructive transition-colors"
                >
                  Clear Selection
                </button>
              )}
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
              {PRESET_SCENES.map((scene) => {
                const isSelected = selectedScene === scene.label;
                const Icon = scene.icon;
                
                return (
                  <button
                    key={scene.id}
                    onClick={() => setSelectedScene(scene.label)}
                    className={cn(
                      "group flex flex-col items-center gap-3 p-4 rounded-2xl border-2 transition-all duration-300 active:scale-95",
                      isSelected 
                        ? "bg-white border-primary shadow-lg shadow-primary/20 scale-105" 
                        : "bg-white border-transparent hover:border-border shadow-sm hover:shadow-md hover:-translate-y-1"
                    )}
                  >
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center transition-transform duration-300",
                      scene.color,
                      isSelected ? "scale-110 shadow-inner" : "group-hover:scale-110"
                    )}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className={cn(
                      "font-bold text-sm text-center",
                      isSelected ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
                    )}>
                      {scene.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Area */}
          <div className="pt-4 border-t border-border flex justify-end">
            <button
              onClick={handleGenerate}
              disabled={!prompt.trim() && !selectedScene}
              className="w-full sm:w-auto px-8 py-5 rounded-2xl font-display font-bold text-xl bg-gradient-to-r from-primary to-accent text-white shadow-xl shadow-primary/30 hover:shadow-2xl hover:shadow-primary/40 hover:-translate-y-1 active:translate-y-0 active:shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none transition-all duration-300 flex items-center justify-center gap-3"
            >
              <span>Create Story</span>
              <Send className="w-6 h-6" />
            </button>
          </div>
          
        </div>
      </div>
    </div>
  );
}
