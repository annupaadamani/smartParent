import { Link } from "wouter";
import { format } from "date-fns";
import { BookOpen, Trash2, Library, Sparkles, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import { useListStories, useStoryMutations } from "@/hooks/use-stories";

export function History() {
  const { data: stories, isLoading, error } = useListStories();
  const { deleteStory } = useStoryMutations();

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this story? It will be gone forever!")) {
      deleteStory.mutate({ id });
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 w-full">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-12">
        <div>
          <h1 className="font-display text-4xl font-bold text-foreground flex items-center gap-3">
            <Library className="w-10 h-10 text-primary" />
            My Story Library
          </h1>
          <p className="text-muted-foreground font-medium mt-2 text-lg">
            All your magical bedtime adventures in one place.
          </p>
        </div>
        
        <Link 
          href="/" 
          className="inline-flex items-center gap-2 px-6 py-3 bg-white border-2 border-primary text-primary font-bold rounded-2xl hover:bg-primary hover:text-white transition-all duration-200 shadow-sm"
        >
          <Sparkles className="w-5 h-5" />
          Create New Story
        </Link>
      </div>

      {isLoading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-64 bg-muted rounded-[2rem] border-2 border-border" />
          ))}
        </div>
      )}

      {error && (
        <div className="p-8 bg-destructive/10 text-destructive rounded-[2rem] flex items-center gap-4">
          <AlertCircle className="w-8 h-8" />
          <div>
            <h3 className="font-bold text-xl">Couldn't load library</h3>
            <p>Please try refreshing the page.</p>
          </div>
        </div>
      )}

      {!isLoading && !error && stories?.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 px-4 text-center bg-white rounded-[3rem] border-2 border-dashed border-border">
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-6">
            <BookOpen className="w-12 h-12 text-primary" />
          </div>
          <h2 className="font-display text-3xl font-bold text-foreground mb-3">No stories yet!</h2>
          <p className="text-lg text-muted-foreground max-w-md mb-8">
            Your bookshelf is looking a little bare. Let's create your first magical adventure!
          </p>
          <Link 
            href="/" 
            className="px-8 py-4 bg-primary text-white font-bold rounded-2xl shadow-lg shadow-primary/30 hover:-translate-y-1 hover:shadow-xl transition-all"
          >
            Start Creating
          </Link>
        </div>
      )}

      {!isLoading && !error && stories && stories.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {stories.map((story, index) => (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              key={story.id}
            >
              <Link 
                href={`/story/${story.id}`}
                className="group block h-full bg-white border-2 border-border rounded-[2rem] p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 hover:border-primary/50 transition-all duration-300 relative overflow-hidden"
              >
                {/* Decorative bookmark ribbon */}
                <div className="absolute top-0 right-8 w-8 h-12 bg-accent opacity-50 rounded-b-lg group-hover:h-16 group-hover:opacity-100 transition-all duration-300" />

                <div className="flex justify-between items-start mb-4 relative z-10">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  
                  <button 
                    onClick={(e) => handleDelete(e, story.id)}
                    disabled={deleteStory.isPending}
                    className="w-10 h-10 bg-white border border-border rounded-xl flex items-center justify-center text-muted-foreground hover:bg-destructive hover:text-white hover:border-destructive transition-colors shadow-sm disabled:opacity-50"
                    title="Delete story"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                <h3 className="font-display font-bold text-2xl text-foreground mb-2 line-clamp-2 leading-tight group-hover:text-primary transition-colors">
                  {story.title}
                </h3>
                
                {story.scene && (
                  <span className="inline-block px-3 py-1 bg-muted text-muted-foreground text-sm font-bold rounded-lg mb-4">
                    {story.scene}
                  </span>
                )}
                
                <p className="text-muted-foreground text-sm line-clamp-3 mb-6">
                  {story.prompt}
                </p>

                <div className="absolute bottom-6 left-6 text-xs font-bold text-muted-foreground/60 uppercase tracking-wider">
                  {format(new Date(story.createdAt), 'MMM d, yyyy')}
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
