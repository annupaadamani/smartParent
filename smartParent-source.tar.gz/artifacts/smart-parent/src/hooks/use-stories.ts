import { useQueryClient } from "@tanstack/react-query";
import {
  useListStories,
  useGetStory,
  useCreateStory,
  useDeleteStory,
  getListStoriesQueryKey,
} from "@workspace/api-client-react";

// Facade hooks to wrap the generated ones with query invalidation

export function useStoryMutations() {
  const queryClient = useQueryClient();

  const createMutation = useCreateStory({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
      },
    },
  });

  const deleteMutation = useDeleteStory({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
      },
    },
  });

  return {
    createStory: createMutation,
    deleteStory: deleteMutation,
  };
}

export { useListStories, useGetStory };
