import { motion } from "framer-motion";
import { Sparkles, Moon, Star } from "lucide-react";

export function LoadingScreen({ message = "Sprinkling magic dust..." }: { message?: string }) {
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background/80 backdrop-blur-lg">
      <div className="relative flex flex-col items-center max-w-md w-full px-6 text-center">
        
        {/* Animated illustration area */}
        <div className="relative w-40 h-40 mb-8 flex items-center justify-center">
          <motion.div
            animate={{ 
              rotate: [0, 10, -10, 0],
              y: [0, -10, 0]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity,
              ease: "easeInOut" 
            }}
            className="absolute"
          >
            <Moon className="w-24 h-24 text-secondary fill-secondary/20" />
          </motion.div>
          
          <motion.div
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.5, 1, 0.5]
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.5
            }}
            className="absolute -top-4 -right-4"
          >
            <Star className="w-10 h-10 text-primary fill-primary/40" />
          </motion.div>

          <motion.div
            animate={{ 
              scale: [1, 1.5, 1],
              opacity: [0.3, 0.8, 0.3]
            }}
            transition={{ 
              duration: 3, 
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1.5
            }}
            className="absolute bottom-2 -left-2"
          >
            <Sparkles className="w-8 h-8 text-accent fill-accent/40" />
          </motion.div>
        </div>

        <motion.h2 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-3xl font-bold text-foreground mb-4"
        >
          {message}
        </motion.h2>
        
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-muted-foreground text-lg"
        >
          Our friendly AI is dreaming up an amazing adventure for your little one. This usually takes a minute or two!
        </motion.p>

        {/* Progress Bar Illusion */}
        <div className="w-full h-3 bg-muted rounded-full mt-8 overflow-hidden relative">
          <motion.div 
            initial={{ width: "0%" }}
            animate={{ width: "90%" }}
            transition={{ duration: 45, ease: "easeOut" }}
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-primary to-secondary rounded-full"
          />
        </div>
      </div>
    </div>
  );
}
