import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { BookOpen, Sparkles, History, Wand2 } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Navigation */}
      <header className="sticky top-0 z-50 w-full border-b border-white/20 bg-white/60 backdrop-blur-xl shadow-sm dark:bg-slate-900/60 dark:border-white/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-12 h-12 bg-gradient-to-tr from-primary to-accent rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary/20 group-hover:scale-105 group-hover:-rotate-3 transition-transform duration-300">
              <Sparkles className="w-6 h-6 fill-white/20" />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-2xl leading-none tracking-wide text-foreground">
                SmartParent
              </span>
              <span className="text-xs font-semibold text-primary uppercase tracking-wider">
                Magic Stories
              </span>
            </div>
          </Link>

          <nav className="flex items-center gap-2 sm:gap-6">
            <Link 
              href="/" 
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 rounded-full font-bold text-sm transition-all duration-200",
                location === "/" 
                  ? "bg-primary/10 text-primary" 
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <Wand2 className="w-4 h-4" />
              <span className="hidden sm:inline">Create</span>
            </Link>
            <Link 
              href="/history" 
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 rounded-full font-bold text-sm transition-all duration-200",
                location === "/history" 
                  ? "bg-secondary/15 text-secondary" 
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <History className="w-4 h-4" />
              <span className="hidden sm:inline">My Stories</span>
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative z-10 w-full max-w-6xl mx-auto">
        {children}
      </main>

      {/* Footer */}
      <footer className="w-full py-8 mt-12 border-t border-border/50 text-center text-muted-foreground">
        <p className="font-medium flex items-center justify-center gap-2">
          Made with <span className="text-primary text-lg">♥</span> for tired parents everywhere.
        </p>
      </footer>
    </div>
  );
}
