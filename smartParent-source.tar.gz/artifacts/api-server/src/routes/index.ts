import { Router, type IRouter } from "express";
import healthRouter from "./health";
import storiesRouter from "./stories";
import openaiRouter from "./openai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(storiesRouter);
router.use(openaiRouter);

export default router;
