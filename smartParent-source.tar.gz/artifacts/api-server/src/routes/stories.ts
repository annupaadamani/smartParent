import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, storiesTable, comicPanelsTable } from "@workspace/db";
import {
  CreateStoryBody,
  GetStoryParams,
  DeleteStoryParams,
  ListStoriesResponse,
  GetStoryResponse,
} from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";

const router: IRouter = Router();

const PRESET_SCENES: Record<string, string> = {
  bedtime: "a cozy bedroom at night with soft moonlight and sleepy animals getting ready for bed",
  "forest adventure": "a magical forest with friendly woodland creatures on a fun adventure",
  "animal friends": "adorable farm and jungle animals making new friends and playing together",
  "space journey": "a colorful rocket ship exploring space with friendly stars and planets",
  "underwater world": "a bright ocean with colorful fish and friendly sea creatures",
  "the big garden": "a sunny garden with giant flowers, butterflies, and tiny garden creatures",
};

async function generateStory(prompt: string, scene?: string | null): Promise<{
  title: string;
  panels: Array<{ narration: string; imagePrompt: string }>;
}> {
  const sceneContext = scene && PRESET_SCENES[scene.toLowerCase()]
    ? `Scene setting: ${PRESET_SCENES[scene.toLowerCase()]}`
    : "";

  const systemPrompt = `You are a creative children's story writer for toddlers (ages 1-4). 
Create a short, simple, visual bedtime story that can be shown as an 8-panel comic strip.
Each panel should have simple action, bright imagery, and calming content suitable for bedtime.
Use simple words a toddler would understand. Make the story warm, safe, and comforting.
${sceneContext}

Respond ONLY with valid JSON in this exact format:
{
  "title": "Story Title Here",
  "panels": [
    { "narration": "Simple caption text for panel 1", "imagePrompt": "Detailed description for illustration of panel 1, children's book style, bright colors, cute characters" },
    { "narration": "Simple caption text for panel 2", "imagePrompt": "Detailed description for illustration of panel 2, children's book style, bright colors, cute characters" },
    { "narration": "Simple caption text for panel 3", "imagePrompt": "Detailed description for illustration of panel 3, children's book style, bright colors, cute characters" },
    { "narration": "Simple caption text for panel 4", "imagePrompt": "Detailed description for illustration of panel 4, children's book style, bright colors, cute characters" },
    { "narration": "Simple caption text for panel 5", "imagePrompt": "Detailed description for illustration of panel 5, children's book style, bright colors, cute characters" },
    { "narration": "Simple caption text for panel 6", "imagePrompt": "Detailed description for illustration of panel 6, children's book style, bright colors, cute characters" },
    { "narration": "Simple caption text for panel 7", "imagePrompt": "Detailed description for illustration of panel 7, children's book style, bright colors, cute characters" },
    { "narration": "Simple caption text for panel 8", "imagePrompt": "Detailed description for illustration of panel 8, children's book style, bright colors, cute characters - final panel should show the character going to sleep or ending happily" }
  ]
}`;

  const response = await openai.chat.completions.create({
    model: "gpt-5.2",
    max_completion_tokens: 2048,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: `Create a bedtime story about: ${prompt}` },
    ],
    response_format: { type: "json_object" },
  });

  const content = response.choices[0]?.message?.content ?? "{}";
  const parsed = JSON.parse(content);
  return parsed;
}

router.get("/stories", async (_req, res): Promise<void> => {
  const stories = await db
    .select()
    .from(storiesTable)
    .orderBy(storiesTable.createdAt);
  res.json(ListStoriesResponse.parse(stories));
});

router.post("/stories", async (req, res): Promise<void> => {
  const parsed = CreateStoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { prompt, scene } = parsed.data;

  const storyData = await generateStory(prompt, scene);

  const [story] = await db
    .insert(storiesTable)
    .values({
      prompt,
      title: storyData.title,
      scene: scene ?? null,
    })
    .returning();

  const imageResults = await Promise.all(
    storyData.panels.map(async (panel, index) => {
      try {
        const imgBuffer = await generateImageBuffer(
          `Children's book illustration: ${panel.imagePrompt}. Style: flat illustration, bright pastel colors, cute and friendly characters, simple background, suitable for toddlers.`,
          "1024x1024"
        );
        return imgBuffer.toString("base64");
      } catch (err) {
        console.error(`Failed to generate image for panel ${index + 1}:`, err);
        return null;
      }
    })
  );

  const panelInserts = await Promise.all(
    storyData.panels.map(async (panel, index) => {
      const [inserted] = await db
        .insert(comicPanelsTable)
        .values({
          storyId: story.id,
          panelNumber: index + 1,
          narration: panel.narration,
          imageB64: imageResults[index],
        })
        .returning();
      return inserted;
    })
  );

  const result = {
    ...story,
    panels: panelInserts,
  };

  res.status(201).json(GetStoryResponse.parse(result));
});

router.get("/stories/:id", async (req, res): Promise<void> => {
  const params = GetStoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [story] = await db
    .select()
    .from(storiesTable)
    .where(eq(storiesTable.id, params.data.id));

  if (!story) {
    res.status(404).json({ error: "Story not found" });
    return;
  }

  const panels = await db
    .select()
    .from(comicPanelsTable)
    .where(eq(comicPanelsTable.storyId, story.id))
    .orderBy(comicPanelsTable.panelNumber);

  res.json(GetStoryResponse.parse({ ...story, panels }));
});

router.delete("/stories/:id", async (req, res): Promise<void> => {
  const params = DeleteStoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [story] = await db
    .delete(storiesTable)
    .where(eq(storiesTable.id, params.data.id))
    .returning();

  if (!story) {
    res.status(404).json({ error: "Story not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
