# Workspace

## Overview

**SmartParent** — an AI-powered bedtime story app for tired parents. Parents enter a prompt or select a preset scene, and the app generates a 4-panel visual comic strip story suitable for toddlers.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (artifacts/smart-parent)
- **API framework**: Express 5 (artifacts/api-server)
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **AI**: OpenAI via Replit AI Integrations (gpt-5.2 for story text, gpt-image-1 for illustrations)
- **Build**: esbuild (CJS bundle)

## Structure

```text
artifacts/
├── api-server/     # Express 5 API server
└── smart-parent/   # React + Vite frontend (served at /)
lib/
├── api-spec/       # OpenAPI spec + Orval codegen
├── api-client-react/ # Generated React Query hooks
├── api-zod/        # Generated Zod schemas
├── db/             # Drizzle ORM schema + DB connection
├── integrations-openai-ai-server/ # OpenAI server integration
```

## Database Tables

- `stories` — story records (id, prompt, title, scene, created_at)
- `comic_panels` — panels per story (id, story_id, panel_number, narration, image_b64)
- `conversations` — chat conversations (not primary use case)
- `messages` — chat messages

## Key Features

1. **Home page**: Hero with prompt textarea + 6 preset scene cards
2. **Story generation**: POST /api/stories → GPT-5.2 generates 4-panel script → gpt-image-1 generates illustrations
3. **Comic strip view**: 4 panels with illustrations + narration captions
4. **Story history**: List of past stories with delete capability

## API Routes

- `GET /api/stories` — list all stories
- `POST /api/stories` — create new story (prompt + optional scene)
- `GET /api/stories/:id` — get story with panels
- `DELETE /api/stories/:id` — delete story

## Environment Variables

- `DATABASE_URL` — PostgreSQL connection string (auto-provisioned)
- `AI_INTEGRATIONS_OPENAI_BASE_URL` — Replit AI proxy URL (auto-provisioned)
- `AI_INTEGRATIONS_OPENAI_API_KEY` — Replit AI proxy key (auto-provisioned)

## Running Codegen

```bash
pnpm --filter @workspace/api-spec run codegen
```

## DB Migrations

```bash
pnpm --filter @workspace/db run push
```
